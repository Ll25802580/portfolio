const c = 50;
  const G = 6;
  const dt = 0.01;
  
  let m87;
  let ball;
  const particles = [];
  
  let radius = 100;
  let angle = 0;
  let speed = 0.03;
  let ang1 = 0;
  
function setup() {
  createCanvas(800,600);
  ellipseMode(RADIUS);
  m87 = new Blackhole(200, 200, 5000);
  
  let start = height/2;
  let end = height/2 - m87.rs*2.6;
  angle = angle + speed;
  //for (let y = end; y < start; y +=5){
  //  particles.push (new Photon(width - 10, y));
  //}
  particles.push (new Photon(width - 20, 30));

}


function draw() {
  background(0);
  fill(255);
  noStroke();
  text("Click screen", 10, 400);
  m87.show();
  
  for (let p of particles){
    m87.pull(p);
    p.update();
    p.show();
  }
}

function mouseClicked(){
  particles.push(new Photon(mouseX, mouseY));
}
